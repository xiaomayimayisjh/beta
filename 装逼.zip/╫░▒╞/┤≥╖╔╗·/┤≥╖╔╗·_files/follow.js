/*document.writeln("<div style=\"width:252px;margin:10px auto;\"><iframe width=\"250\" height=\"100\" class=\"share_self\"  frameborder=\"0\" scrolling=\"no\"")
document.writeln("src=\"http://widget.weibo.com/weiboshow/index.php?")
document.writeln("language=&width=250&height=100&fansRow=2&ptype=1&speed=0&skin=1&")
document.writeln("isTitle=0&noborder=1&isWeibo=0&isFans=0&uid=2832482174&verifier=d71718ca&dpc=1\"></iframe></div>")*/


/*document.writeln('<div style="width:510px;margin:10px auto;"><iframe width="250" height="90" class="share_self"  frameborder="0" scrolling="no" src="http://widget.weibo.com/weiboshow/index.php?language=&width=250&height=90&fansRow=2&ptype=1&speed=0&skin=3&isTitle=0&noborder=1&isWeibo=0&isFans=0&uid=5052963352&verifier=08118085&dpc=1"></iframe>&nbsp;&nbsp;<iframe src="http://follow.v.t.qq.com/index.php?c=follow&a=quick&appkey=801484131&sign=b9b10d49&v=2&name=html5tricks&style=1&t=1393976749230&f=1" frameborder="0" scrolling="auto" width="227" height="75" marginwidth="0" marginheight="0" allowtransparency="true"></iframe></div>');*/